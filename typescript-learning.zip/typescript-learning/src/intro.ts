function add(a: any, b:any){

	return a + b;
}


let sum = add(5,10);

console.log(add);