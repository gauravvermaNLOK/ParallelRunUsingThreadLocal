let s1: string = "Way";
let s2: string = "2";
let s3: string = "Automation"

console.log(s1 + s2 + s3)

console.log(10+20+s2+s3)

console.log(s1 + (10+20)+s2 + s3)

